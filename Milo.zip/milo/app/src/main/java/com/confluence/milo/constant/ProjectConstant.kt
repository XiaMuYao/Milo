package com.confluence.milo.constant

const val BASE_URL = "https://www.wanandroid.com/"

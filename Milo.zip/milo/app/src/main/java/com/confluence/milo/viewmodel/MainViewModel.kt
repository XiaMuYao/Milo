package com.confluence.milo.viewmodel

import com.confluence.milobox.base.BaseViewModel

/**
 * ================================================
 * 介    绍：
 * ================================================
 */
class MainViewModel : BaseViewModel() {

    override fun initData() {

    }


    fun getBanner() {
//        request {
//            private val repository: MainRepository
//            val data = repository.getBanner()
//            data
//        }
    }


}